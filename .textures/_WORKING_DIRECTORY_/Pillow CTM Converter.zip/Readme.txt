Open console.
cd to 'Pillow CTM Converter'
> pillow_venv\scripts\activate
> python pillow_venv\Converter\MT-Fusion-Converter.py

Textures to convert go to "import"
Converted textures go to "export"

Adjust setup.txt to change formats:
#import format
#export format
#resolution (16)

Converter: https://github.com/Midnighttigger/MT-Fusion-Converter/tree/main