If you wish to use this texturepack as the default pack for your public minecraft server, please provide information at spawn as to where you got it from
and provide a link back to my youtube channel.

http://www.youtube.com/c/fWhip

Credits:

Big Thanks to Ryuma_13 for the sugarcane texture


